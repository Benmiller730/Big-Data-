-- Databricks notebook source
-- MAGIC %python
-- MAGIC FilePath = "/FileStore/tables/clinicaltrial_2019_csv.gz"
-- MAGIC FilePath2= "/FileStore/tables/clinicaltrial_2020_csv.gz"
-- MAGIC FilePath3= "/FileStore/tables/clinicaltrial_2021_csv.gz"
-- MAGIC dbutils.fs.cp(FilePath, "file:/tmp/")
-- MAGIC dbutils.fs.cp(FilePath2, "file:/tmp/")
-- MAGIC dbutils.fs.cp(FilePath3, "file:/tmp/")

-- COMMAND ----------

-- MAGIC %sh
-- MAGIC gunzip /tmp/clinicaltrial_2019_csv.gz
-- MAGIC gunzip /tmp/clinicaltrial_2020_csv.gz
-- MAGIC gunzip /tmp/clinicaltrial_2021_csv.gz

-- COMMAND ----------

-- MAGIC %python
-- MAGIC dbutils.fs.cp("file:/tmp/clinicaltrial_2019_csv", "file:/tmp/clinicaltrial_2019.csv")
-- MAGIC dbutils.fs.mv("file:/tmp/clinicaltrial_2019.csv", "FileStore/tables/")
-- MAGIC 
-- MAGIC dbutils.fs.cp("file:/tmp/clinicaltrial_2020_csv", "file:/tmp/clinicaltrial_2020.csv")
-- MAGIC dbutils.fs.mv("file:/tmp/clinicaltrial_2020.csv", "FileStore/tables/")
-- MAGIC 
-- MAGIC dbutils.fs.cp("file:/tmp/clinicaltrial_2021_csv", "file:/tmp/clinicaltrial_2021.csv")
-- MAGIC dbutils.fs.mv("file:/tmp/clinicaltrial_2021.csv", "FileStore/tables/") 

-- COMMAND ----------

-- MAGIC %python
-- MAGIC dbutils.fs.mkdirs("dbfs:/FileStore/tables/clinicaltrial19")
-- MAGIC dbutils.fs.mv("dbfs:/FileStore/tables/clinicaltrial_2019.csv","dbfs:/FileStore/tables/clinicaltrial19")
-- MAGIC 
-- MAGIC dbutils.fs.mkdirs("dbfs:/FileStore/tables/clinicaltrial20")
-- MAGIC dbutils.fs.mv("dbfs:/FileStore/tables/clinicaltrial_2020.csv","dbfs:/FileStore/tables/clinicaltrial20")
-- MAGIC 
-- MAGIC dbutils.fs.mkdirs("dbfs:/FileStore/tables/clinicaltrial21")
-- MAGIC dbutils.fs.mv("dbfs:/FileStore/tables/clinicaltrial_2021.csv","dbfs:/FileStore/tables/clinicaltrial21")

-- COMMAND ----------

-- MAGIC %python
-- MAGIC dbutils.fs.ls("dbfs:/FileStore/tables/clinicaltrial19")

-- COMMAND ----------

-- MAGIC %python
-- MAGIC dbutils.fs.mkdirs("dbfs:/FileStore/tables/mesh")
-- MAGIC dbutils.fs.cp("dbfs:/FileStore/tables/mesh.csv", "dbfs:/FileStore/tables/mesh")

-- COMMAND ----------

-- MAGIC %python
-- MAGIC dbutils.fs.mkdirs("dbfs:/FileStore/tables/pharma")
-- MAGIC dbutils.fs.cp("dbfs:/FileStore/tables/pharma.csv", "dbfs:/FileStore/tables/pharma")

-- COMMAND ----------

CREATE TABLE clinicaltrial21 (
ID STRING,
Sponser STRING,
Status STRING,
StartDate STRING,
EndDate STRING,
Type STRING,
Submission STRING,
Conditions STRING,
Interventions STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '|'
LOCATION 'dbfs:/FileStore/tables/clinicaltrial21/';

-- COMMAND ----------

SELECT * FROM clinicaltrial21

-- COMMAND ----------

-- DBTITLE 1,PROBLEM #1:


-- COMMAND ----------

SELECT * FROM clinicaltrial21
ORDER BY ID;

-- COMMAND ----------

CREATE VIEW clinicaltrial21view AS
SELECT *
FROM clinicaltrial21
WHERE LEFT(ID,3) = "NCT"

-- COMMAND ----------

SELECT ID, COUNT(ID) 
FROM clinicaltrial21view
GROUP BY ID
HAVING COUNT(ID) > 1

-- COMMAND ----------

SELECT * FROM clinicaltrial21view

-- COMMAND ----------

SELECT DISTINCT COUNT(ID) FROM clinicaltrial21view;  

-- COMMAND ----------

-- DBTITLE 1,PROBLEM #2:


-- COMMAND ----------

SELECT Type, COUNT(Type) AS Freq 
FROM clinicaltrial21view
GROUP BY Type
ORDER BY Freq desc;

-- COMMAND ----------

-- DBTITLE 1,PROBLEM #3:


-- COMMAND ----------

Create Table Table7 As (
Select Split_Conditions, Count(Split_Conditions) as Freq
FROM clinicaltrial21 lateral view explode(split(Conditions,',')) Conditions AS Split_Conditions  
WHERE Split_Conditions != ""
Group BY Split_Conditions
Order BY Freq Desc
);

-- COMMAND ----------

select * from table7

-- COMMAND ----------

-- DBTITLE 1,PROBLEM #4:


-- COMMAND ----------

CREATE TABLE Mesh(
Condition STRING,
hierarchy_identifiers STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
LOCATION 'dbfs:/FileStore/tables/mesh';

-- COMMAND ----------

CREATE VIEW MeshIdentifiers AS (
SELECT Condition, LEFT(hierarchy_identifiers,3) AS H_I FROM Mesh);

-- COMMAND ----------

select * from MeshIdentifiers

-- COMMAND ----------

Create table Con_HI_Freq5 AS
SELECT Condition, H_I, Freq   
FROM table7, MeshIdentifiers 
WHERE Split_Conditions = Condition;

-- COMMAND ----------

Select * From Con_HI_Freq5

-- COMMAND ----------

Select H_I, Sum(Freq) as amount from Con_HI_Freq5
group by H_I
order by amount desc;

-- COMMAND ----------

-- DBTITLE 1,PROBLEM #5:


-- COMMAND ----------

CREATE TABLE pharma1(
Company string,
Parent_Company string)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '",""'
LOCATION 'dbfs:/FileStore/tables/pharma';

-- COMMAND ----------

create view PharmaCom1 AS (
select * from pharma1
where Company != "Company");

-- COMMAND ----------

SELECT Sponser, COUNT(Sponser) AS Freq
fROM clinicaltrial21view
WHERE Sponser 
NOT IN (SELECT Parent_Company
        FROM PharmaCom1)
GROUP BY Sponser
SORT BY Freq DESC
LIMIT 10; 

-- COMMAND ----------

-- DBTITLE 1,PROBLEM #6


-- COMMAND ----------

Create view CompletedDate1 as
select LEFT(EndDate, 3) as Month, COUNT(EndDate) as Freq
From clinicaltrial21
where Status = "Completed" and EndDate LIKE '%2021%'
Group by EndDate
ORDER BY Freq desc;

-- COMMAND ----------

Select * from CompletedDate1

-- COMMAND ----------

Select status, count(status) as freq
from clinicaltrial21
group by status
sort by freq desc;
