# Databricks notebook source
FilePath3= "/FileStore/tables/clinicaltrial_2021_csv.gz"
dbutils.fs.cp(FilePath3, "file:/tmp/")

# COMMAND ----------

# MAGIC %sh
# MAGIC gunzip /tmp/clinicaltrial_2021_csv.gz

# COMMAND ----------

dbutils.fs.cp("file:/tmp/clinicaltrial_2021_csv", "file:/tmp/clinicaltrial_2021.csv")
dbutils.fs.mv("file:/tmp/clinicaltrial_2021.csv", "FileStore/tables/")

# COMMAND ----------

# DBTITLE 1,Problem #1:


# COMMAND ----------

DF21 = spark.read.csv("dbfs:/FileStore/tables/clinicaltrial_2021.csv", sep = "|", header=True).distinct()
DF21.show()

# COMMAND ----------

DF21.count()

# COMMAND ----------

# DBTITLE 1,Problem #2:


# COMMAND ----------

DF21Type = DF21.select("Type")
DF21Type.show()

# COMMAND ----------

DF21TypeFreq = DF21Type.groupBy(['Type']).count()
DF21TypeFreq.sort("count", ascending=False).show()

# COMMAND ----------

# DBTITLE 1,Problem #3:


# COMMAND ----------

from pyspark.sql.functions import split, explode
DF21Con = DF21.select("Conditions").withColumn(("Conditions"), explode(split("Conditions", ",")))
DF21ConFreq = DF21Con.groupBy("Conditions").count()
DF21ConFreq.sort("count", ascending=False).show(5)
