# Databricks notebook source
# DBTITLE 1,LOADING THE FILES:


# COMMAND ----------

dbutils.fs.ls("/FileStore/tables/")

# COMMAND ----------

FilePath = "/FileStore/tables/clinicaltrial_2019_csv.gz"
FilePath2= "/FileStore/tables/clinicaltrial_2020_csv.gz"
FilePath3= "/FileStore/tables/clinicaltrial_2021_csv.gz"
dbutils.fs.cp(FilePath, "file:/tmp/")
dbutils.fs.cp(FilePath2, "file:/tmp/")
dbutils.fs.cp(FilePath3, "file:/tmp/")

# COMMAND ----------

# MAGIC %sh
# MAGIC gunzip /tmp/clinicaltrial_2019_csv.gz
# MAGIC gunzip /tmp/clinicaltrial_2020_csv.gz
# MAGIC gunzip /tmp/clinicaltrial_2021_csv.gz

# COMMAND ----------

dbutils.fs.ls("file:/tmp/")

# COMMAND ----------

dbutils.fs.cp("file:/tmp/clinicaltrial_2019_csv", "file:/tmp/clinicaltrial_2019.csv")
dbutils.fs.mv("file:/tmp/clinicaltrial_2019.csv", "FileStore/tables/")

dbutils.fs.cp("file:/tmp/clinicaltrial_2020_csv", "file:/tmp/clinicaltrial_2020.csv")
dbutils.fs.mv("file:/tmp/clinicaltrial_2020.csv", "FileStore/tables/")

dbutils.fs.cp("file:/tmp/clinicaltrial_2021_csv", "file:/tmp/clinicaltrial_2021.csv")
dbutils.fs.mv("file:/tmp/clinicaltrial_2021.csv", "FileStore/tables/")

# COMMAND ----------

dbutils.fs.ls("FileStore/tables/")

# COMMAND ----------

# DBTITLE 1,PROBLEM #1:


# COMMAND ----------

RDD = sc.textFile("dbfs:/FileStore/tables/clinicaltrial_2019.csv").distinct() #READ THE FILE INTO A RDD. DISTINCT() ENSURES ALL ROWS ARE UNIQUE AND NO DUPELICATES
header = RDD.take(1)[0] #HEADER ROW
RDD2019 = RDD.filter(lambda x: x != header) #FILTER OUT HEADER TO GET ONLY THE INDIVDUAL STUDIES 
RDD2019.count() #COUNT THE NUMBER OF STUDIES 

# COMMAND ----------

RDD = sc.textFile("dbfs:/FileStore/tables/clinicaltrial_2020.csv").distinct() #READ THE FILE INTO A RDD. DISTINCT() ENSURES ALL ROWS ARE UNIQUE AND NO DUPELICATES
header = RDD.take(1)[0] #HEADER ROW
RDD2020 = RDD.filter(lambda x: x != header) #FILTER OUT HEADER TO GET ONLY THE INDIVDUAL STUDIES 
RDD2020.count() #COUNT THE NUMBER OF STUDIES 

# COMMAND ----------

RDD = sc.textFile("dbfs:/FileStore/tables/clinicaltrial_2021.csv").distinct() #READ THE FILE INTO A RDD. DISTINCT() ENSURES ALL ROWS ARE UNIQUE AND NO DUPELICATES
header = RDD.take(1)[0] #HEADER ROW
RDD2021 = RDD.filter(lambda x: x != header) #FILTER OUT HEADER TO GET ONLY THE INDIVDUAL STUDIES 
RDD2021.count() #COUNT THE NUMBER OF STUDIES 

# COMMAND ----------

RDD = sc.textFile("dbfs:/FileStore/tables/clinicaltrial_2021.csv").distinct()
header = RDD.take(1)[0]
RDD2021 = RDD.filter(lambda x: x != header)
RDD2021.count()

# COMMAND ----------

# DBTITLE 1,PROBLEM #2:


# COMMAND ----------

RDD.take(5)

# COMMAND ----------

SplitRDD = RDD2019.map(lambda s: (s.split("|")[5],1))
FreqRDD = SplitRDD.reduceByKey(lambda x,y: x+y)
SortedRDD = FreqRDD.sortBy(lambda x: x[1], ascending= False)
SortedRDD.collect()

# COMMAND ----------

SplitRDD = RDD2020.map(lambda s: (s.split("|")[5],1))
FreqRDD = SplitRDD.reduceByKey(lambda x,y: x+y)
SortedRDD = FreqRDD.sortBy(lambda x: x[1], ascending= False)
SortedRDD.collect()

# COMMAND ----------

SplitRDD = RDD2021.map(lambda s: (s.split("|")[5],1))
FreqRDD = SplitRDD.reduceByKey(lambda x,y: x+y)
SortedRDD = FreqRDD.sortBy(lambda x: x[1], ascending= False)
SortedRDD.collect()

# COMMAND ----------

EA_RDD = RDD2021.map(lambda s: s.split("|")).map(lambda x: (x[5],x[7])).filter(lambda s: s[0] == "Expanded Access")
EA_RDD.take(69)

# COMMAND ----------

SplitRDD = RDD2021.map(lambda s: (s.split("|")[5],1))
SplitRDD.take(3)

# COMMAND ----------

# DBTITLE 1,PROBLEM #3:


# COMMAND ----------

SplitRDD = RDD2019.map(lambda s: s.split("|")[7]).flatMap(lambda s: s.split(","))
FiltRDD = SplitRDD.filter(lambda x: x != "").map(lambda x: (x,1))
FreqRDD = FiltRDD.reduceByKey(lambda x,y: x+y)
SortedRDD2019 = FreqRDD.sortBy(lambda x: x[1], ascending= False)
SortedRDD2019.take(5)

# COMMAND ----------

SplitRDD = RDD2020.map(lambda s: s.split("|")[7]).flatMap(lambda s: s.split(","))
FiltRDD = SplitRDD.filter(lambda x: x != "").map(lambda x: (x,1))
FreqRDD = FiltRDD.reduceByKey(lambda x,y: x+y)
SortedRDD2020 = FreqRDD.sortBy(lambda x: x[1], ascending= False)
SortedRDD2020.take(5)

# COMMAND ----------

SplitRDD = RDD2021.map(lambda s: s.split("|")[7]).flatMap(lambda s: s.split(","))
FiltRDD = SplitRDD.filter(lambda x: x != "").map(lambda x: (x,1))
FreqRDD = FiltRDD.reduceByKey(lambda x,y: x+y)
SortedRDD2021 = FreqRDD.sortBy(lambda x: x[1], ascending= False)
SortedRDD2021.take(5)

# COMMAND ----------

SortedRDD2021.count()

# COMMAND ----------

# DBTITLE 1,PROBLEM #4:


# COMMAND ----------

MeshRDD = sc.textFile("dbfs:/FileStore/tables/mesh.csv")
MeshRDD.take(10)

# COMMAND ----------

MeshRDD = sc.textFile("dbfs:/FileStore/tables/mesh.csv") 
MeshRDDF = MeshRDD.map(lambda x: x.split(",")).map(lambda x: (x[0],x[1]))
MeshRDDS = MeshRDDF.map(lambda x: (x[0],x[1].split("."))).map(lambda x: ((x[0],x[1][0]),1)).reduceByKey(lambda x,y: x+y)
MeshRDDP = MeshRDDS.map(lambda x: (x[0][0],(x[0][1], x[1])))
RDDJoin = SortedRDD2019.join(MeshRDDP).map(lambda x: (x[0],x[1][1][0],x[1][0],x[1][1][1]))
RDDJ1 = RDDJoin.map(lambda x: (x[1], x[2]*x[3])).reduceByKey(lambda x,y:x+y).sortBy(lambda x: x[1], ascending= False)
RDDJ1.take(5)

# COMMAND ----------

MeshRDD = sc.textFile("dbfs:/FileStore/tables/mesh.csv") 
MeshRDDF = MeshRDD.map(lambda x: x.split(",")).map(lambda x: (x[0],x[1]))
MeshRDDS = MeshRDDF.map(lambda x: (x[0],x[1].split("."))).map(lambda x: ((x[0],x[1][0]),1)).reduceByKey(lambda x,y: x+y)
MeshRDDP = MeshRDDS.map(lambda x: (x[0][0],(x[0][1], x[1])))
RDDJoin = SortedRDD2020.join(MeshRDDP).map(lambda x: (x[0],x[1][1][0],x[1][0],x[1][1][1]))
RDDJ1 = RDDJoin.map(lambda x: (x[1], x[2]*x[3])).reduceByKey(lambda x,y:x+y).sortBy(lambda x: x[1], ascending= False)
RDDJ1.take(5)

# COMMAND ----------

MeshRDD = sc.textFile("dbfs:/FileStore/tables/mesh.csv") 
MeshRDDF = MeshRDD.map(lambda x: x.split(",")).map(lambda x: (x[0],x[1]))
MeshRDDS = MeshRDDF.map(lambda x: (x[0],x[1].split("."))).map(lambda x: ((x[0],x[1][0]),1)).reduceByKey(lambda x,y: x+y)
MeshRDDP = MeshRDDS.map(lambda x: (x[0][0],(x[0][1], x[1])))
RDDJoin = SortedRDD2021.join(MeshRDDP).map(lambda x: (x[0],x[1][1][0],x[1][0],x[1][1][1]))
RDDJ1 = RDDJoin.map(lambda x: (x[1], x[2]*x[3])).reduceByKey(lambda x,y:x+y).sortBy(lambda x: x[1], ascending= False)
RDDJ1.take(5)

# COMMAND ----------

MeshRDD = sc.textFile("dbfs:/FileStore/tables/mesh.csv") 
MeshRDDF = MeshRDD.map(lambda x: x.split(",")).map(lambda x: (x[0],x[1]))
MeshRDDS = MeshRDDF.map(lambda x: (x[0],x[1].split("."))).map(lambda x: ((x[0],x[1][0]),1)).reduceByKey(lambda x,y: x+y)
MeshRDDP = MeshRDDS.map(lambda x: (x[0][0],(x[0][1], x[1])))
MeshRDDP.take(10)

# COMMAND ----------

# DBTITLE 1,PROBLEM #5:


# COMMAND ----------

PharmaRDD = sc.textFile("dbfs:/FileStore/tables/pharma.csv")
PharmaRDD1 = PharmaRDD.map(lambda x: x.split('","')).map(lambda x: x[1])
headerPharma = PharmaRDD1.take(1)[0]
PhRDD = PharmaRDD1.filter(lambda x: x != headerPharma)

# COMMAND ----------

PharmaRDD.take(1)

# COMMAND ----------

RDD19 = RDD2019.map(lambda s: (s.split("|")[1],1)).reduceByKey(lambda x,y: x+y).sortBy(lambda x: x[1], ascending= False)

PhRDDlist = PhRDD.collect()

RDD_Sponser19 = RDD19.filter(lambda s: s[0] not in PhRDDlist)
RDD_Sponser19.take(10)

# COMMAND ----------

RDD20 = RDD2020.map(lambda s: (s.split("|")[1],1)).reduceByKey(lambda x,y: x+y).sortBy(lambda x: x[1], ascending= False)

PhRDDlist = PhRDD.collect()

RDD_Sponser20 = RDD20.filter(lambda s: s[0] not in PhRDDlist)
RDD_Sponser20.take(10)

# COMMAND ----------

RDD21 = RDD2021.map(lambda s: (s.split("|")[1],1)).reduceByKey(lambda x,y: x+y).sortBy(lambda x: x[1], ascending= False)

PhRDDlist = PhRDD.collect()

RDD_Sponser21 = RDD21.filter(lambda s: s[0] not in PhRDDlist)
RDD_Sponser21.take(10)

# COMMAND ----------

# DBTITLE 1,PROBLEM #6:


# COMMAND ----------

RDD2019.take(2)

# COMMAND ----------

Completed_RDD2019 = RDD2019.map(lambda s: (s.split("|"))).map(lambda f: (f[2], f[4])).filter(lambda f: "2019" in f[1] and "Completed" in f[0]).map(lambda x: (x[1],1)).reduceByKey(lambda x,y: x+y).sortBy(lambda x: x[1], ascending= False)

Completed_RDD2019DF = Completed_RDD2019.toDF().toPandas()
print(Completed_RDD2019DF)

# COMMAND ----------

import pandas as pd
import numpy as np

Completed_RDD2019DF.plot.bar()

# COMMAND ----------

Completed_RDD2020 = RDD2020.map(lambda s: (s.split("|"))).map(lambda f: (f[2], f[4])).filter(lambda f: "2020" in f[1] and "Completed" in f[0]).map(lambda x: (x[1],1)).reduceByKey(lambda x,y: x+y).sortBy(lambda x: x[1], ascending= False)

Completed_RDD2020DF = Completed_RDD2020.toDF().toPandas()
print(Completed_RDD2020DF)

# COMMAND ----------

Completed_RDD2021 = RDD2021.map(lambda s: (s.split("|"))).map(lambda f: (f[2], f[4])).filter(lambda f: "2021" in f[1] and "Completed" in f[0]).map(lambda x: (x[1],1)).reduceByKey(lambda x,y: x+y).sortBy(lambda x: x[1], ascending= False)
Completed_RDD2021.collect()

# COMMAND ----------

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

Completed_RDD2021DF = Completed_RDD2021.toDF().toPandas().reindex([1,5,0,4,3,2,6,7,8,9])
first_column = Completed_RDD2021DF.iloc[:, 0].astype('string')

Completed_RDD2021DF.plot(kind='bar', colormap='BrBG').set_xticklabels(Completed_RDD2021DF._1)
plt.xticks(rotation=30, horizontalalignment="center")
plt.title("Completed Studies Each Month In 2021")
plt.ylabel("Completed Studies")
plt.xlabel("Month")

# COMMAND ----------

Completed_RDD2021 = RDD2021.map(lambda s: (s.split("|"))).map(lambda f: (f[2], f[4])).filter(lambda f: "2021" in f[1]).filter(lambda f: "Recruiting" in f[0]).map(lambda x: (x[1],1)).reduceByKey(lambda x,y: x+y).sortBy(lambda x: x[1], ascending= False)
Completed_RDD2021.collect()

# COMMAND ----------

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

Completed_RDD2021DF = Completed_RDD2021.toDF().toPandas().reindex([10,11,8,9,7,4,6,5,2,1,3,0])
first_column = Completed_RDD2021DF.iloc[:, 0].astype('string')

Completed_RDD2021DF.plot(kind='bar', colormap='BrBG').set_xticklabels(Completed_RDD2021DF._1)
plt.xticks(rotation=30, horizontalalignment="center")
plt.title("Recruiting Studies Each Month In 2021")
plt.ylabel("Completed Studies")
plt.xlabel("Month")
